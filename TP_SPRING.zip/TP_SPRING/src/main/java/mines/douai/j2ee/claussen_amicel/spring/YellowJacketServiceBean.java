package mines.douai.j2ee.claussen_amicel.spring;

import java.math.BigDecimal;

public interface YellowJacketServiceBean {

	BigDecimal getPeopleCount(String country);
	
}
