package mines.douai.j2ee.claussen_amicel.spring;

public interface YellowJacketBean {

	String getCountryName();

	void setCountryName(String country);

	void printPIB();

}
